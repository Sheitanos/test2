Space invader-------------
Url     : http://codes-sources.commentcamarche.net/source/51278-space-invaderAuteur  : aurelardieDate    : 14/08/2013
Licence :
=========

Ce document intitul� � Space invader � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Voila le code d'un vieux jeux en HTML et javascript. Je l'ai test&eacute; avec I
E, Chrome et FireFox.
<br />Sous Ie et chrome utiliser [j] pour gauche [l] pour
 droite et [i] pour tirer.
<br />Sous FireFox il faut utiliser les fl&ecirc;che
s.
<br />Les images ne sont pas li&eacute;s et la personnalisation est n&eacute
;cessaire pour que le jeux ressemble &agrave; quelques chose.
<br /><a name='so
urce-exemple'></a><h2> Source / Exemple : </h2>
<br /><pre class='code' data-m
ode='basic'>
&lt;html&gt;

&lt;script&gt;

nm = 0
m = new Array()
var tm 
= new Array()
var lastFire = 0

function missile(x,y,ord) {
	this.ord = ord

	this.x=x
	this.y=y
	this.v=-120
	this.t0 = new Date().getTime()/1000
	this
.miss = &quot;&lt;div id='mis_&quot;+this.ord+&quot;' class='mis'&gt;&lt;img src
='missile.bmp'/&gt;&lt;/div&gt;&quot;

	document.getElementById(&quot;content&
quot;).innerHTML+= this.miss
	document.getElementById(&quot;mis_&quot;+this.ord
).style.top=y
	document.getElementById(&quot;mis_&quot;+this.ord).style.left=x

	this.tire = function() {
		if(this.y&gt;-24){
			now = new Date().getTime()/
1000
			var dt = now-this.t0	
			var yaux = this.y
			this.y = this.v*dt+this
.y
			document.getElementById(&quot;mis_&quot;+this.ord).style.top=this.y
			f
or( var i=4 ; i&gt;=0 ; i--){
				if (this.y&lt;a.y0+60*i+30 &amp;&amp; yaux&gt
;a.y0+60*i){
					for( var j=0 ; j&lt;6 ; j++){
						if (this.x&lt;(a.x0+75*j
+58) &amp;&amp; this.x+8&gt;(a.x0+75*j)){
							var id = &quot;vas_&quot;+(i*6
+j)
							if(document.getElementById(id)!=null){
								document.getElementB
yId(&quot;content&quot;).removeChild(document.getElementById(&quot;mis_&quot;+th
is.ord))
								document.getElementById(&quot;armee&quot;).removeChild(documen
t.getElementById(id))
								if (a.battle.length==1){
									alert(&quot;Yo
u win motha' fucka'&quot;)
								} else {
									a.heigh=0	
									for(
 var p = 0 ; p&lt;a.battle.length ; p++){
										if (a.battle[p].id == id){

											a.battle.splice(p,1)
										} else {
											a.heigh=Math.ma
x(a.battle[p].y+30, a.heigh)
										}
									}
								}	
								retur
n true
							}
							
						}
					}
				}
			}
			tm[this.ord]=setTime
out(&quot;m[&quot;+this.ord+&quot;].tire()&quot;, 100) 
		} else {
			document
.getElementById(&quot;content&quot;).removeChild(document.getElementById(&quot;m
is_&quot;+this.ord))
		}
	} 	
}

function vassel(x, y, id){
	this.x = x 

	this.y = y
	this.id = id
}

function armee(){
	this.nVas = 30
	this.vy = 
20
	this.Xorig = 185
	this.x0 = 185
	this.y0 = 0
	this.nax = 0
	this.t0 = n
ew Date().getTime()/1000
	this.battle = new Array()
	this.heigh = 300
	for( i
 = 0 ; i&lt;this.nVas ; i++){
		this.battle[i] = new vassel((i%6)*75, Math.floo
r(i/6)*60, &quot;vas_&quot;+i) 
	}
	this.draw = function(){
		for( i = 0 ; i&
lt;this.nVas ; i++){
			document.getElementById(&quot;armee&quot;).innerHTML +=
 &quot;&lt;div id='vas_&quot;+i+&quot;' class='vas' style='left:&quot;+this.batt
le[i].x+&quot;px; top: &quot;+this.battle[i].y+&quot;px'&gt;&lt;img src='invader
.bmp'/&gt;&lt;/div&gt;&quot;
		}
	}
	this.run = function() {
		this.nax++
	
	var now = new Date().getTime()/1000 
		var dt = now-this.t0
		this.x0 = 60*Ma
th.sin(2*3.1416*dt/5)+this.Xorig
		document.getElementById(&quot;armee&quot;).s
tyle.left = this.x0
		this.y0=this.vy*dt
		document.getElementById(&quot;armee
&quot;).style.top = this.y0
		if (a.heigh+a.y0&gt;600){
			alert(&quot;You loo
se dirty bastard&quot;)
		} else {
 			setTimeout(&quot;a.run()&quot;, 100) 

		}
	}
}

function Ship(){
	this.x0=374
	this.y0=550
	this.accel=0
	this
.speed=0
	this.frot=.8
	this.t0 = new Date().getTime()/1000
	this.move = func
tion (now){
		this.x0 = Math.min(778,Math.max(0, this.x0))
		if (this.x0 &gt; 
778 || this.x0 &lt; 0){
			this.accel=0 
			this.speed=0
		}
		dt = now-this
.t0
		this.x0 = this.accel*dt*dt/2+this.frot*this.speed*dt+this.x0
		this.spee
d = this.accel*dt+this.frot*this.speed
		this.t0=now
		document.getElementById
(&quot;ship&quot;).style.left = this.x0 
	}
}

sh = new Ship()

function k
eypress(e) {
// 	alert(&quot;keypress&quot;)
	if (window.event){
		e = window
.event
		if (e.keyCode==108){
			sh.accel+=70
		} else if (e.keyCode==106){

			sh.accel-=70
		} else if (e.keyCode==105) {
			var now = new Date().getTime
()/1000
			if (nm==0 || now-lastFire&gt;.3){
				lastFire = now
				nm++
			
	m[nm] = new missile(sh.x0+12,sh.y0,nm)
				m[nm].tire()
			}
		} else if (e.
keyCode==113){
			clearTimeout(t)
		} 
	} else {
		if (e.keyCode==39){
			s
h.accel+=70
		} else if (e.keyCode==37){
			sh.accel-=70
		} else if (e.keyCo
de==38) {
			var now = new Date().getTime()/1000
			if (nm==0 || now-lastFire&
gt;.3){
				lastFire = now
				nm++
				m[nm] = new missile(sh.x0+12,sh.y0,nm
)
				m[nm].tire()
			}
		} else if (e.keyCode==0 &amp;&amp; e.charCode==113)
{
			clearTimeout(t)
		} 
	return true;
	}
}

function release(e) {
// 	
alert(&quot;release&quot;)
	if (window.event){
		e = window.event
		if (e.key
Code==74||e.keyCode==76){
			sh.accel=0
		}
	} else {
		if (e.keyCode==39 ||
 e.keyCode==37){
			sh.accel=0
		}
		return true;
	}
	
}

&lt;/script&gt
;
&lt;style&gt;
body {
	margin: 0px ;
	padding: 0px;
}

#ship {
	positio
n: absolute ;
	background: yellow ;
	width: 32px;
	height: 32px;
	top: 564px
;
	left: 374px ;
}

#content {
	z-index:-1;
	background: black  ;
	positi
on: absolute;
	width: 800px ;
	height: 600px ;
}

.mis {
	position: absolu
te ;
	background: black ;
	width: 8px;
	height: 24px;
}

.vas {
	position
: absolute ;
	background: red ;
	width: 50px ;
	height: 30px ;
}

#armee {

	position: absolute; 
	left: 185px ;
	top: 0px ;
}

&lt;/style&gt;
&lt;b
ody onkeypress=&quot;keypress(event)&quot; onkeyup=&quot;release(event)&quot; &g
t;

&lt;div id=&quot;content&quot;&gt;
&lt;div id=&quot;armee&quot;&gt;&lt;/d
iv&gt;
&lt;div id=&quot;ship&quot;&gt;&lt;img src=&quot;vas.bmp&quot;/&gt;&lt;/
div&gt;
&lt;/div&gt;
&lt;/body&gt;
&lt;script&gt;

function faire(){
	now 
= new Date().getTime()/1000
	sh.move(now)
	t = setTimeout(&quot;faire()&quot;,
 100) 
}

a = new armee() 
a.draw()
a.run()
faire()
&lt;/script&gt;

&l
t;/html&gt;
</pre>
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<b
r />La procipale critique de mon code est que tout est cod&eacute; en dur. Les l
argeurs des &eacute;l&eacute;ments, les vitesses, acc&eacute;l&eacute;rations. C
ela rend ces modifs plus fastidieuses. Le but n'&eacute;tait pas de faire un pro
gramme trop g&eacute;n&eacute;rique avec trop de variables. Si vous le voulez je
 pourrais faire ce travail, ce n'est pas grand chose.
<br />Le code peut facile
ment &ecirc;tre aussi modifi&eacute; pour augmenter l'amplitude des invaders, la
 fr&eacute;quence des tirs. les vitesses des diff&eacute;rents &eacute;l&eacute;
ments et donc faire des niveaux de difficult&eacute;s croissant.
